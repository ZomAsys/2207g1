﻿namespace HRSystem
{
    public class Employee
    {
        public string FullName { get; set; } // ФИО
        public string Position { get; set; } // Должность
        public DateTime HireDate { get; set; } // Дата найма
        public int WorkHours { get; set; } // Рабочие часы
        public string EmploymentStatus { get; set; } // Статус занятости 
    }
}