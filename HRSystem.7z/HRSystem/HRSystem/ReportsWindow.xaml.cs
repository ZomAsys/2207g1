﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows;
using Microsoft.Win32;

namespace HRSystem
{
    public partial class ReportsWindow : Window
    {
        private List<Employee> _employees;

        // Конструктор, принимающий список сотрудников
        public ReportsWindow(List<Employee> employees)
        {
            InitializeComponent();
            _employees = employees;
        }

        // Формирование отчета
        private void GenerateReport_Click(object sender, RoutedEventArgs e)
        {
            var Report = new StringBuilder();
            Report.AppendLine("Отчет по сотрудникам");
            Report.AppendLine("===================");
            Report.AppendLine();

            foreach (var Employee in _employees)
            {
                Report.AppendLine($"ФИО: {Employee.FullName}");
                Report.AppendLine($"Должность: {Employee.Position}");
                Report.AppendLine($"Дата найма: {Employee.HireDate:dd.MM.yyyy}");
                Report.AppendLine($"Отработано часов: {Employee.WorkHours}");
                Report.AppendLine($"Статус: {Employee.EmploymentStatus}");
                Report.AppendLine();
            }

            txtReport.Text = Report.ToString(); // Выводим отчет в TextBox
        }

        // Сохранение отчета в файл
        private void SaveReport_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtReport.Text))
            {
                MessageBox.Show("Сначала сформируйте отчет.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

      
            else
                {

                    MessageBox.Show("Отчет успешно сохранен.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }
    }
