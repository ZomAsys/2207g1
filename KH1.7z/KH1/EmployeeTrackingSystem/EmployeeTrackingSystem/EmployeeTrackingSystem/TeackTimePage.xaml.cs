﻿using System.Windows.Controls;

namespace EmployeeTrackingSystem
{
    public partial class TrackTimePage : Page
    {
        public TrackTimePage()
        {
            InitializeComponent();
            EmployeesListView.ItemsSource = EmployeeRepository.GetEmployees();
        }
    }
}