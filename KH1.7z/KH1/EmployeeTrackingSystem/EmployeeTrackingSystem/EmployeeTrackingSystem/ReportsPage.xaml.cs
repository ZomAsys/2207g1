﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace EmployeeTrackingSystem
{
    public partial class ReportsPage : Page
    {
        public ReportsPage()
        {
            InitializeComponent();
        }

        private void GenerateReportButton_Click(object sender, RoutedEventArgs e)
        {
            var reportData = EmployeeRepository.GetEmployees()
                .Select(emp => new
                {
                    emp.FullName,
                    emp.Position,
                    emp.WorkedHours
                }).ToList();

            ReportDataGrid.ItemsSource = reportData;
        }
    }
}