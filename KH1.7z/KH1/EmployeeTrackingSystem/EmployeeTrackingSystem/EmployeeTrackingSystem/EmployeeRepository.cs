﻿using System.Collections.Generic;

namespace EmployeeTrackingSystem
{
    public static class EmployeeRepository
    {
        private static List<Employee> _employees = new List<Employee>();

        public static List<Employee> GetEmployees() => _employees;

        public static void AddEmployee(Employee employee) => _employees.Add(employee);
    }
}