﻿namespace EmployeeTrackingSystem
{
    public class Employee
    {
        public string FullName { get; set; }
        public string Position { get; set; }
        public DateTime HireDate { get; set; }
        public string WorkSchedule { get; set; }
        public string EmploymentStatus { get; set; }
        public int WorkedHours { get; set; }
    }
}