﻿using System.Windows;
using System.Windows.Controls;

namespace EmployeeTrackingSystem
{
    public partial class EditEmployeePage : Page
    {
        public EditEmployeePage()
        {
            InitializeComponent();
            EmployeeComboBox.ItemsSource = EmployeeRepository.GetEmployees();
        }

        private void SaveChangesButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedEmployee = EmployeeComboBox.SelectedItem as Employee;
            if (selectedEmployee == null)
            {
                MessageBox.Show("Выберите сотрудника!");
                return;
            }

            selectedEmployee.WorkSchedule = (NewWorkScheduleComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            selectedEmployee.EmploymentStatus = (NewEmploymentStatusComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();

            MessageBox.Show("Изменения сохранены!");
        }
    }
}