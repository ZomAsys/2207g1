
namespace EmployeeTrackingSystem
{
    public class Class1
    {
    }

}
