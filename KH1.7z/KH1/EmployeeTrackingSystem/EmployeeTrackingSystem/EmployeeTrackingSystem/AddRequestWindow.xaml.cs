﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace EmployeeTrackingSystem
{
    public partial class AddEmployeePage : Page
    {
        public AddEmployeePage()
        {
            InitializeComponent();
        }

        private void AddEmployeeButton_Click(object sender, RoutedEventArgs e)
        {
            string fullName = FullNameTextBox.Text;
            string position = PositionTextBox.Text;
            DateTime hireDate = HireDatePicker.SelectedDate ?? DateTime.Now;
            string workSchedule = (WorkScheduleComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            string employmentStatus = (EmploymentStatusComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();

            // Добавление сотрудника в репозиторий
            EmployeeRepository.AddEmployee(new Employee
            {
                FullName = fullName,
                Position = position,
                HireDate = hireDate,
                WorkSchedule = workSchedule,
                EmploymentStatus = employmentStatus
            });

            MessageBox.Show($"Сотрудник {fullName} добавлен!");
        }
    }
}