﻿using System.Windows;

namespace EmployeeTrackingSystem
{
    public partial class MainWindow : Window
    {
   

        public MainWindow()
        {
            InitializeComponent();
        }

        private void NavigateToAddEmployeePage(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new AddEmployeePage());
        }

        private void NavigateToEditEmployeePage(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new EditEmployeePage());
        }

        private void NavigateToTrackTimePage(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new TrackTimePage());
        }

        private void NavigateToReportsPage(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new ReportsPage());
        }
    }
}