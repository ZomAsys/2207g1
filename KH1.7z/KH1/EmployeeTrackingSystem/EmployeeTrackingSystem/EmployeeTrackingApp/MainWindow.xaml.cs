﻿using System.Windows;

namespace EmployeeTrackingApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}