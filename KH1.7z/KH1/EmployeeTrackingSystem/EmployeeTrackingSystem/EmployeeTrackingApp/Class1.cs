
namespace EmployeeTrackingApp
{
    public class Class1
    {
    }

}
