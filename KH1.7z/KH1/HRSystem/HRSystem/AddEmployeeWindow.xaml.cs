﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace HRSystem
{
    public partial class AddEmployeeWindow : Window
    {
        public Employee NewEmployee { get; private set; }

        public AddEmployeeWindow()
        {
            InitializeComponent();
        }

        private void AddEmployee_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFullName.Text) || string.IsNullOrWhiteSpace(txtPosition.Text) || dpHireDate.SelectedDate == null || string.IsNullOrWhiteSpace(txtWorkHours.Text))
            {
                MessageBox.Show("Заполните все поля.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Создаем нового сотрудника
            NewEmployee = new Employee
            {
                FullName = txtFullName.Text,
                Position = txtPosition.Text,
                HireDate = dpHireDate.SelectedDate.Value,
                WorkHours = int.Parse(txtWorkHours.Text),
                EmploymentStatus = (cbEmploymentStatus.SelectedItem as ComboBoxItem)?.Content.ToString()
            };

            DialogResult = true; // Закрываем окно с результатом "ОК"
            Close();
        }
    }
}