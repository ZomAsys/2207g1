﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace HRSystem
{
    public partial class EditEmployeeWindow : Window
    {
        public Employee EditedEmployee { get; private set; }

        public EditEmployeeWindow(Employee employee)
        {
            InitializeComponent();
            EditedEmployee = employee;

            // Заполняем поля данными выбранного сотрудника
            txtFullName.Text = employee.FullName;
            txtPosition.Text = employee.Position;
            dpHireDate.SelectedDate = employee.HireDate;
            txtWorkHours.Text = employee.WorkHours.ToString();

            // Устанавливаем выбранный статус в ComboBox
            foreach (ComboBoxItem item in cbEmploymentStatus.Items)
            {
                if (item.Content.ToString() == employee.EmploymentStatus)
                {
                    cbEmploymentStatus.SelectedItem = item;
                    break;
                }
            }
        }

        private void SaveChanges_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFullName.Text) || string.IsNullOrWhiteSpace(txtPosition.Text) || dpHireDate.SelectedDate == null || string.IsNullOrWhiteSpace(txtWorkHours.Text))
            {
                MessageBox.Show("Заполните все поля.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Обновляем данные сотрудника
            EditedEmployee.FullName = txtFullName.Text;
            EditedEmployee.Position = txtPosition.Text;
            EditedEmployee.HireDate = dpHireDate.SelectedDate.Value;
            EditedEmployee.WorkHours = int.Parse(txtWorkHours.Text);
            EditedEmployee.EmploymentStatus = (cbEmploymentStatus.SelectedItem as ComboBoxItem)?.Content.ToString();

            DialogResult = true; // Закрываем окно с результатом "ОК"
            Close();
        }
    }
}