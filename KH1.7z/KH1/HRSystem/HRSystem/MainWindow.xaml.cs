﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace HRSystem
{
    public partial class MainWindow : Window
    {
        private List<Employee> _employees; // Список сотрудников

        public MainWindow()
        {
            InitializeComponent();
            _employees = new List<Employee>(); // Инициализируем список
            LoadEmployeeData(); // Загружаем данные в таблицу при запуске
        }

        // Метод для загрузки данных в таблицу
        private void LoadEmployeeData()
        {
            // Пример данных для таблицы
            _employees = new List<Employee>
            {
                new Employee { FullName = "Иванов И.И.", Position = "Программист", HireDate = new DateTime(2023, 1, 15), WorkHours = 160, EmploymentStatus = "Активен" },
                new Employee { FullName = "Петров П.П.", Position = "Менеджер", HireDate = new DateTime(2022, 11, 10), WorkHours = 120, EmploymentStatus = "В отпуске" },
                new Employee { FullName = "Сидоров С.С.", Position = "Аналитик", HireDate = new DateTime(2023, 3, 20), WorkHours = 140, EmploymentStatus = "На больничном" }
            };

            dgEmployees.ItemsSource = _employees; // Привязываем данные к таблице
        }

        // Обработчик кнопки "Добавить сотрудника"
        private void AddEmployee_Click(object sender, RoutedEventArgs e)
        {
            AddEmployeeWindow addEmployeeWindow = new AddEmployeeWindow();
            if (addEmployeeWindow.ShowDialog() == true)
            {
                // Добавляем нового сотрудника в список
                _employees.Add(addEmployeeWindow.NewEmployee);
                dgEmployees.Items.Refresh(); // Обновляем таблицу
            }
        }

        // Обработчик кнопки "Редактировать сотрудника"
        private void EditEmployee_Click(object sender, RoutedEventArgs e)
        {
            if (dgEmployees.SelectedItem is Employee selectedEmployee)
            {
                EditEmployeeWindow editEmployeeWindow = new EditEmployeeWindow(selectedEmployee);
                if (editEmployeeWindow.ShowDialog() == true)
                {
                    dgEmployees.Items.Refresh(); // Обновляем таблицу
                }
            }
            else
            {
                MessageBox.Show("Выберите сотрудника для редактирования.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        // Обработчик кнопки "Удалить сотрудника"
        private void DeleteEmployee_Click(object sender, RoutedEventArgs e)
        {
            if (dgEmployees.SelectedItem is Employee selectedEmployee)
            {
                var result = MessageBox.Show("Вы уверены, что хотите удалить сотрудника?", "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    _employees.Remove(selectedEmployee);
                    dgEmployees.Items.Refresh(); // Обновляем таблицу
                }
            }
            else
            {
                MessageBox.Show("Выберите сотрудника для удаления.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        // Обработчик кнопки "Сформировать отчет"
        private void GenerateReports_Click(object sender, RoutedEventArgs e)
        {
            // Передаем список сотрудников в окно отчетности
            ReportsWindow reportsWindow = new ReportsWindow(_employees);
            reportsWindow.ShowDialog();
        }
    }
}