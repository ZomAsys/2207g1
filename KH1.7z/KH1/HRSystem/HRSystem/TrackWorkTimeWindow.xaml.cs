﻿using System.Windows;

namespace HRSystem
{
    public partial class TrackWorkTimeWindow : Window
    {
        public TrackWorkTimeWindow()
        {
            InitializeComponent();
            // Пример данных для DataGrid
            dgEmployees.ItemsSource = new[]
            {
                new { ФИО = "Иванов И.И.", Должность = "Программист", ОтработаноЧасов = 160 },
                new { ФИО = "Петров П.П.", Должность = "Менеджер", ОтработаноЧасов = 120 },
                new { ФИО = "Сидоров С.С.", Должность = "Аналитик", ОтработаноЧасов = 140 }
            };
        }
    }
}